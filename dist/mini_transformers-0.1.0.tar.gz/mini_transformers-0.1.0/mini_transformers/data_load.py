from importlib import resources
import mini_transformers
from enum import auto, Enum

class TextDatasets(Enum):
    
    def _generate_next_value_(name, start, count, last_values):
         return name + '.txt'
    
    shakespeare = auto()

def get_text_file(filename: str):
    
    with resources.path(mini_transformers, 'data') as data_path:
        data_file = data_path / filename
        return data_file
    
    
def load_text_data(filepath: str):
    
    with open(filepath, 'r', encoding='utf-8') as data_file:
        text = data_file.read()
        
    return text


